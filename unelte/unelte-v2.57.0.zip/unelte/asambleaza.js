/* Pune bucățile la loc și scoate un index.html gata de urcat.
   Verifică întâi că părțile pe care nu le atingem au rămas neschimbate, apoi că
   fișierul ieșit e valid și complet. Dacă ceva nu e în regulă, nu scrie nimic —
   mai bine niciun fișier decât unul stricat.

   Rulare:  node asambleaza.js [versiune-nouă]   */

const fs = require('fs');
const crypto = require('crypto');

let cap = fs.readFileSync('parti/cap.html', 'utf8');
const biblioteci = fs.readFileSync('parti/biblioteci.js', 'utf8');
let aplicatie = fs.readFileSync('parti/aplicatie.js', 'utf8');
const coada = fs.readFileSync('parti/coada.html', 'utf8');
const amprenta = JSON.parse(fs.readFileSync('parti/amprenta.json', 'utf8'));

// 1. Părțile neatinse trebuie să fie exact cele de la desfacere.
const acum = crypto.createHash('sha256').update(cap + biblioteci + coada).digest('hex');
if (acum !== amprenta.neatinse) {
  console.error('✕ Bibliotecile sau stilul s-au modificat. Nu asamblez.');
  console.error('  Repară-le sau desfă din nou fișierul bun.');
  process.exit(1);
}

// 2. Versiunea nouă, dacă e cerută, se schimbă peste tot deodată.
const versiuneNoua = process.argv[2];
if (versiuneNoua) {
  const vechea = (amprenta.versiune || '').replace('IAS ', '');
  if (!vechea) { console.error('✕ Nu știu versiunea veche.'); process.exit(1); }
  /* Se schimbă DOAR constanta care ține versiunea aplicației. Înainte se
     înlocuia peste tot, iar asta stampila și intrările vechi din „Ce e nou":
     „Garajul", scris cândva ca v2.34.27, ajungea la fiecare livrare să pară cea
     mai nouă schimbare și apărea din nou pe ecran. */
  const tipar = new RegExp('(\\bri\\s*=\\s*")' + vechea.replace(/\./g, '\\.') + '(")');
  if (!tipar.test(aplicatie)) {
    console.error('✕ Nu găsesc constanta de versiune (' + vechea + ') în cod.');
    process.exit(1);
  }
  aplicatie = aplicatie.replace(tipar, '$1' + versiuneNoua + '$2');
  // Titlul paginii și mesajul de pornire poartă și ele numărul; le schimbăm doar
  // în copia din memorie, ca amprenta părților neatinse să rămână valabilă.
  cap = cap.split(vechea).join(versiuneNoua);
  console.log('  versiune:', vechea, '→', versiuneNoua);
}

const html = cap + biblioteci + aplicatie + coada;

// 3. Verificări asupra fișierului ieșit, înainte să atingem discul.
const probe = [
  ['începe cu doctype', html.startsWith('<!DOCTYPE html>')],
  ['se termină cu </html>', html.trim().endsWith('</html>')],
  ['are stilul complet', html.includes('--violet:') && html.includes('glow-cadru')],
  ['are aplicația', html.includes('Instructor Auto Sistem')],
  ['are garajul', html.includes('Hatchback') && html.includes('iasVehiculDinFisier')],
  ['are licențierea', html.includes('9F3K')],
  /* Intrările din „Ce e nou" trebuie să-și păstreze versiunea lor. Dacă apar
     două cu același număr, înseamnă că ștampila de versiune a scăpat unde nu
     trebuia — exact defectul care făcea să reapară mesajul „Garajul". */
  /* Numărul de versiune are un înțeles, nu e un contor: prima cifră —
     schimbare mare; a doua — o funcție nouă sau alta; a treia — doar înfățișare.

     A PATRA cifră există și ea, și nu e o greșeală: însemnează o schimbare în
     partea cu disponibilitatea trimisă de elev — pagina lui și ce ține de ea.
     Se ține deoparte anume, ca munca de acolo să nu se amestece cu aplicația.
     Un „v2.49.0.1" e deci corect scris. Nu-l îndrepta.
     Dacă intrarea din „Ce e nou" vorbește despre o funcție, dar s-a mișcat doar
     a treia cifră, e semn că numărul minte. */
  ['versiunea se potrivește cu ce scrie în istoric', (() => {
    const m = html.match(/v:\s*"v(\d+)\.(\d+)\.(\d+)"[\s\S]{0,400}?puncte:\s*\[([\s\S]{0,600}?)\]/);
    if (!m) return true;
    const vizual = m[3] !== '0';
    /* Textul din istoric e scris cu coduri de litere (\u0219, \xEE), nu cu
       litere adevărate, așa că le căutăm pe amândouă. */
    const vorbeDeFunctie = /po\\u021Bi |poti |alegi |apare |Set\\u0103ri|Setari|adaug|se desface/i.test(m[4]);
    return !(vizual && vorbeDeFunctie);
  })()],

  ['istoricul nu a fost ștampilat', (() => {
    const versiuni = (html.match(/v:\s*"(v[0-9.]+)"/g) || []).map(x => x.split('"')[1]);
    return versiuni.length === new Set(versiuni).size;
  })()],
  ['scripturile au rămas la fel',
    (html.match(/<script>/g) || []).length === amprenta.etichete.deschise
    && (html.match(/<\/script>/g) || []).length === amprenta.etichete.inchise],
];
let bune = 0;
probe.forEach(([nume, ok]) => { console.log((ok ? '  ✓ ' : '  ✕ ') + nume); if (ok) bune++; });
if (bune !== probe.length) { console.error('\n✕ Fișierul nu e bun. Nu l-am scris.'); process.exit(1); }

fs.writeFileSync('index.html', html);
console.log('\n  index.html scris:', Math.round(html.length / 1024), 'KB');

// 4. Service workerul poartă numărul versiunii, ca telefoanele să ia fișierul nou.
if (versiuneNoua) {
  const sw = fs.readFileSync('sw.js', 'utf8');
  const nou = sw.replace(/ias-v[0-9.]+/, 'ias-' + versiuneNoua);   // oricare ar fi fost înainte
  if (nou === sw) console.log('  ! atenție: n-am putut schimba versiunea în sw.js');
  else { fs.writeFileSync('sw.js', nou); console.log('  sw.js actualizat.'); }
}
