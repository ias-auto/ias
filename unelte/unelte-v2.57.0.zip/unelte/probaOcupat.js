/* Textul „când sunt ocupat", de trimis elevului care întreabă când poți.     */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const azi = new Date().toISOString().slice(0, 10);
const luni = (() => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d })();
const zi = (k) => { const d = new Date(luni); d.setDate(d.getDate() + k); return d.toISOString().slice(0, 10) };

const rez = [];
const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);

/* Luni: 08:30–10:00 și 12:00–19:00 (trei ședințe lipite). Marți: 11:30–18:00. */
const sessions = [
  { id: '1', studentId: 's1', date: zi(0), startMin: 510, duration: 90, status: 'scheduled', type: 'included' },
  { id: '2', studentId: 's1', date: zi(0), startMin: 720, duration: 90, status: 'scheduled', type: 'included' },
  { id: '3', studentId: 's1', date: zi(0), startMin: 810, duration: 90, status: 'scheduled', type: 'included' },
  { id: '4', studentId: 's1', date: zi(0), startMin: 900, duration: 240, status: 'scheduled', type: 'included' },
  { id: '5', studentId: 's1', date: zi(1), startMin: 690, duration: 390, status: 'scheduled', type: 'included' },
];

const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students: [{ id: 's1', name: 'Oarecare Ion', lastName: 'Oarecare', firstName: 'Ion',
        includedHours: 10, weeklyLimit: 3, payments: [] }],
      sessions,
      settings: { workDays: [1,2,3,4,5,6], startMin: 510, endMin: 1200, sessionMin: 90,
        stepMin: 30, currency: 'lei' },
    }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({
      cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'],
    }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {};
    w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const textul = () => {
  const f = [...doc().querySelectorAll('div')]
    .filter(x => /whitespace-pre-line/.test(x.className || ''))[0];
  return f ? f.textContent : '';
};

(async () => {
  await pauza(3400);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f =>
    clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(600);
  clic([...doc().querySelectorAll('nav button')].find(x => /Calendar/.test(x.textContent)));
  await pauza(900);

  const buton = [...doc().querySelectorAll('button')].find(x => /Când sunt ocupat/.test(x.textContent));
  cer('butonul e în Calendar', !!buton, buton ? buton.textContent.trim() : 'nu-l găsesc');
  clic(buton); await pauza(900);

  const t = textul();
  cer('luni se adună într-un singur interval', /Luni \d+ \w+ — ocupat 08:30–10:00, 12:00–19:00/.test(t),
    (t.match(/Luni[^\n]*/) || ['—'])[0]);
  cer('  marți la fel', /Marți \d+ \w+ — ocupat 11:30–18:00/.test(t),
    (t.match(/Marți[^\n]*/) || ['—'])[0]);
  cer('  zilele goale se spun libere', /liber toată ziua/.test(t),
    (t.match(/\w+ \d+ \w+ — liber toată ziua/) || ['—'])[0]);
  cer('  iar duminica, zi nelucrătoare', /Duminică \d+ \w+ — nu lucrez/.test(t),
    (t.match(/Duminică[^\n]*/) || ['—'])[0]);
  cer('nu scrie numele niciunui elev', !/Oarecare/.test(t),
    'elevul n-are treabă cu cine sunt ceilalți');

  /* Se poate cere și pe mai mult de o săptămână. */
  const sel = [...doc().querySelectorAll('select')].find(x => /o săptămână/.test(x.textContent));
  cer('se poate cere și pe mai multe săptămâni', !!sel,
    sel ? [...sel.options].map(o => o.textContent).join(', ') : 'nu găsesc alegerea');
  if (sel) {
    const pune = Object.getOwnPropertyDescriptor(d.window.HTMLSelectElement.prototype, 'value').set;
    pune.call(sel, '14');
    sel.dispatchEvent(new d.window.Event('change', { bubbles: true }));
    await pauza(600);
    const randuri = (textul().match(/— (ocupat|liber|nu lucrez)/g) || []).length;
    cer('  pe două săptămâni ies paisprezece zile', randuri === 14, randuri + ' zile');
  }
  cer('are buton de trimis pe WhatsApp',
    [...doc().querySelectorAll('button')].some(x => /Trimite pe WhatsApp/.test(x.textContent)));

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(42) + (dt || '')));
  const cazute = rez.filter(r => r[0] === '✕').length;
  console.log('\n  ' + (rez.length - cazute) + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
