#!/bin/sh
# Rulează probele date ca argumente; scrie câte un rând pentru fiecare.
# Ceasul stă pe UTC: probele își iau „azi” din ora universală, iar noaptea,
# între 00:00 și 02:00 ora României, ar ieși ziua de ieri și ar pica degeaba.
for t in "$@"; do
  r=$(TZ=UTC timeout 100 node $t.js 2>&1 | grep -oE '[0-9]+ din [0-9]+|✓ gruparea' | tail -1)
  printf "  %-22s %s\n" "$t" "${r:-FĂRĂ REZULTAT}"
done
