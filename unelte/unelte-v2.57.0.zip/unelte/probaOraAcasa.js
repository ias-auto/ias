/* La examenul teoretic, anunțurile de pe Acasă spun și ora, dacă e trecută. */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const ceasFix = require('./ceasFix.js');
const ACUM = ceasFix.luneaViitoare();
const iso = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const zi = (k) => { const d = new Date(ACUM); d.setDate(d.getDate() + k); return iso(d); };
const rez = []; const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const elev = (id, nume, extra) => Object.assign({ id, name: nume, lastName: nume.split(' ')[0], firstName: nume.split(' ')[1], includedHours: 15, weeklyLimit: 3, payments: [] }, extra || {});
const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    ceasFix(w, ACUM);
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students: [elev('e1', 'Ionescu Maria', { theoryExamDate: zi(0), theoryExamOra: 600 }),
        elev('e2', 'Stan Radu', { theoryExamDate: zi(4), theoryExamOra: 810 }),
        elev('e3', 'Marin Elena', { theoryExamDate: zi(6) }),
        elev('e4', 'Popescu Andrei', { examDate: zi(5), examPeriod: 'am' })],
      sessions: [], settings: { workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei' },
    }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: zi(0), drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', zi(0));
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
(async () => {
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);
  const butoane = () => [...doc().querySelectorAll('button')].map(x => x.textContent.replace(/\s+/g, ' ').trim());
  const azi = butoane().find(t => /dă azi examenul teoretic/.test(t));
  cer('cine dă teoreticul azi apare cu ora', /Ionescu Maria dă azi examenul teoretic, la 10:00/.test(azi || ''), azi || 'nu găsesc anunțul');
  const grup = [...doc().querySelectorAll('button')].find(x => /^Examene teoretice/.test(x.textContent.trim()));
  clic(grup); await pauza(400);
  const rand = (re) => butoane().find(t => re.test(t)) || '';
  cer('în lista de examene teoretice, ora stă lângă dată', /Stan Radu · .+, 13:30/.test(rand(/^Stan Radu/)), rand(/^Stan Radu/));
  cer('fără oră trecută pe fișă, rămâne doar data', !!rand(/^Marin Elena/) && !/\d\d:\d\d/.test(rand(/^Marin Elena/)), rand(/^Marin Elena/));
  const practic = [...doc().querySelectorAll('button')].find(x => /^Examene practice/.test(x.textContent.trim()));
  cer('la practic nu se adaugă nicio oră', !!practic && !/\d\d:\d\d/.test(practic.textContent), practic ? practic.textContent.replace(/\s+/g, ' ').trim() : '');
  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(52) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
