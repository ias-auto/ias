/* Disponibilitatea pe fișă, ca un calendar. Atingi o zi și alegi cum poate;
   cu „La fel în fiecare…” se pune pe toate zilele de felul ei, fără, doar pe
   data aceea. Se scrie odată cu fișa, iar planul o respectă — inclusiv ziua
   anume, care trece înaintea regulii zilei din săptămână.                    */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const ceasFix = require('./ceasFix.js');
const ACUM = ceasFix.luneaViitoare();                    // luni, 07:00
const iso = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const zi = (k) => { const d = new Date(ACUM); d.setDate(d.getDate() + k); return iso(d); };
const azi = zi(0);
const rez = []; const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));

const porneste = (students) => new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    ceasFix(w, ACUM);
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students, sessions: [],
      settings: { workDays: [1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei',
        defaultWeeklyLimit: 7, rateTypes: [{ id: 'included', name: 'Ore incluse', price: 100 }] },
    }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const unelte = (d) => {
  const doc = () => d.window.document;
  const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
  const alege = (el, v) => { if (!el) return; el.value = String(v); el.dispatchEvent(new d.window.Event('change', { bubbles: true })); };
  return {
    doc, clic, alege,
    gata: async () => {
      await pauza(3200);
      [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
      await pauza(500);
    },
    fisa: async (nume) => {
      clic([...doc().querySelectorAll('nav button')].find(x => /Elevi/.test(x.textContent))); await pauza(700);
      const s = [...doc().querySelectorAll('span')].find(x => new RegExp(nume).test(x.textContent) && x.textContent.length < 60);
      clic(s && s.closest('button, [role=button]')); await pauza(900);
      clic([...doc().querySelectorAll('button')].find(x => /Editeaz/.test(x.textContent))); await pauza(900);
      clic([...doc().querySelectorAll('button')].find(x => /^Disponibilitate/.test(x.textContent.trim()))); await pauza(400);
    },
    celula: (t) => doc().querySelector(`[data-ias-zi-disp="${t}"]`),
    text: (t) => { const c = doc().querySelector(`[data-ias-zi-disp="${t}"]`); return c ? c.getAttribute('aria-label').split(': ').slice(1).join(': ') : '—'; },
    salvat: () => JSON.parse(d.window.localStorage.getItem('ias:app-data')).students,
  };
};

(async () => {
  /* ---------- 1. pe fișă ---------- */
  const A = porneste([
    { id: 'e1', name: 'Popescu Andrei', lastName: 'Popescu', firstName: 'Andrei', includedHours: 20, weeklyLimit: 7, payments: [] },
  ]);
  const u = unelte(A); await u.gata(); await u.fisa('Popescu Andrei');
  const cal = u.doc().querySelector('[data-ias-cal-disp]');
  cer('fișa arată calendarul pe 4 săptămâni', !!cal && cal.querySelectorAll('[data-ias-zi-disp]').length === 28);
  cer('  fără regulă, fiecare zi spune „oricând”', /fără regulă \(oricând\)/.test(u.text(zi(1))), u.text(zi(1)));
  cer('  duminica, în care nu lucrezi, nu se atinge', u.celula(zi(6)).disabled && /nu lucrezi/.test(u.text(zi(6))));

  /* marți: de la 16:00, pe toate marțile */
  u.clic(u.celula(zi(1))); await pauza(300);
  const ed = () => u.doc().querySelector('[data-ias-editor-disp]');
  cer('o zi atinsă deschide alegerea, sub calendar', !!ed() && /Marți, /.test(ed().textContent) && ed().querySelectorAll('[data-ias-fel-disp]').length === 6);
  cer('  „La fel în fiecare marți” e pornit', u.doc().querySelector('[data-ias-lafel-disp]').getAttribute('aria-pressed') === 'true');
  u.clic(u.doc().querySelector('[data-ias-fel-disp="dupa"]')); await pauza(250);
  u.alege(u.doc().querySelector('[data-ias-ora-disp="lo"]'), 960); await pauza(250);
  cer('marți „de la 16:00” se pune pe toate marțile', [1, 8, 15, 22].every(k => u.text(zi(k)) === 'de la 16:00'), [1, 8, 15].map(k => u.text(zi(k))).join(' / '));

  /* marțea de peste o săptămână: doar atunci, indisponibil */
  u.clic(u.celula(zi(8))); await pauza(250);
  u.clic(u.doc().querySelector('[data-ias-lafel-disp]')); await pauza(250);
  cer('  oprit „La fel…”, ziua pornește cu regula marților', /de la 16:00/.test(ed().textContent) && /Doar pe /.test(ed().textContent));
  u.clic(u.doc().querySelector('[data-ias-fel-disp="nu"]')); await pauza(250);
  cer('  apoi „Indisponibil” se pune doar pe ziua aceea', u.text(zi(8)) === 'indisponibil, doar atunci' && u.text(zi(1)) === 'de la 16:00' && u.text(zi(15)) === 'de la 16:00',
    [1, 8, 15].map(k => u.text(zi(k))).join(' / '));

  /* litera de sus: toate joile, între 10 și 13 */
  u.clic(u.doc().querySelector('[data-ias-sapt-disp="4"]')); await pauza(250);
  cer('litera de sus deschide „În fiecare joi”', !!ed() && /În fiecare joi/.test(ed().textContent) && !u.doc().querySelector('[data-ias-lafel-disp]'));
  u.clic(u.doc().querySelector('[data-ias-fel-disp="intre"]')); await pauza(250);
  u.alege(u.doc().querySelector('[data-ias-ora-disp="lo"]'), 600); await pauza(150);
  u.alege(u.doc().querySelector('[data-ias-ora-disp="hi"]'), 780); await pauza(250);
  cer('  joile: între 10:00 și 13:00', [3, 10].every(k => u.text(zi(k)) === 'între 10:00 și 13:00'), u.text(zi(3)));

  /* sâmbăta: nimic, apoi „Fără regulă” o duce înapoi */
  u.clic(u.celula(zi(5))); await pauza(200);
  u.clic(u.doc().querySelector('[data-ias-fel-disp="nu"]')); await pauza(200);
  u.clic(u.doc().querySelector('[data-ias-sterge-disp]')); await pauza(200);
  cer('„Fără regulă” o duce înapoi la oricând', /fără regulă/.test(u.text(zi(5))) && !ed(), u.text(zi(5)));

  /* săptămânile următoare */
  const prima = u.doc().querySelector('[data-ias-zi-disp]').getAttribute('data-ias-zi-disp');
  u.clic(u.doc().querySelector('[aria-label="Săptămânile următoare"]')); await pauza(250);
  const dupa = u.doc().querySelector('[data-ias-zi-disp]').getAttribute('data-ias-zi-disp');
  cer('săgeata duce la următoarele 4 săptămâni', dupa === zi(28) && prima === zi(0), prima + ' → ' + dupa);
  u.clic([...u.doc().querySelectorAll('button')].find(x => x.textContent.trim() === 'Azi')); await pauza(250);

  u.clic([...u.doc().querySelectorAll('button')].find(x => /Salvează modificările/.test(x.textContent))); await pauza(600);
  const el = u.salvat()[0];
  cer('salvat: regula marților și a joilor', JSON.stringify(el.dispZile) === JSON.stringify({ 2: { fel: 'dupa', lo: 960 }, 4: { fel: 'intre', lo: 600, hi: 780 } }), JSON.stringify(el.dispZile));
  cer('  și ziua anume', JSON.stringify(el.dispDate) === JSON.stringify({ [zi(8)]: { fel: 'nu' } }), JSON.stringify(el.dispDate));

  /* ---------- 2. elevul cu regula veche ---------- */
  const B = porneste([
    { id: 'e2', name: 'Ionescu Maria', lastName: 'Ionescu', firstName: 'Maria', includedHours: 20, weeklyLimit: 7, payments: [],
      availFrom: 840, availTo: 1200, availDays: [1, 2, 3, 4, 5], tura: '12-24', turaData: zi(-3), turaOra: 420, availParity: 'even' },
  ]);
  const v = unelte(B); await v.gata(); await v.fisa('Ionescu Maria');
  cer('regula veche se vede pe fiecare zi', v.text(zi(0)) === 'între 14:00 și 20:00' && v.text(zi(5)) === 'indisponibil', v.text(zi(0)) + ' / sâmbătă: ' + v.text(zi(5)));
  const vechi = () => v.doc().querySelector('[data-ias-vechi-disp]');
  cer('tura și zilele pare de dinainte se văd sub calendar', !!vechi() && /12 cu 24/.test(vechi().textContent) && /pare/.test(vechi().textContent));
  v.clic(v.celula(zi(2))); await pauza(200);
  v.clic(v.doc().querySelector('[data-ias-fel-disp="oricand"]')); await pauza(250);
  cer('schimbată o zi, celelalte rămân exact cum erau', v.text(zi(2)) === 'oricând' && v.text(zi(0)) === 'între 14:00 și 20:00' && v.text(zi(5)) === 'indisponibil',
    [0, 2, 5].map(k => v.text(zi(k))).join(' / '));
  v.clic([...vechi().querySelectorAll('button')].find(x => /Scoate/.test(x.textContent))); await pauza(250);
  cer('„Scoate” le șterge', !vechi());
  v.clic([...v.doc().querySelectorAll('button')].find(x => /Salvează modificările/.test(x.textContent))); await pauza(600);
  const m = v.salvat()[0];
  cer('salvat: regula veche pusă pe zile, câmpurile vechi golite', m.availFrom === '' && m.availTo === '' && Array.isArray(m.availDays) && !m.availDays.length
    && m.dispZile[1].fel === 'intre' && m.dispZile[3].fel === 'oricand' && m.dispZile[6].fel === 'nu' && m.dispZile[0].fel === 'nu' && !m.tura && m.availParity === 'all',
    JSON.stringify(m.dispZile));

  /* ---------- 3. planul ascultă de ziua anume ---------- */
  const zileLibere = { 1: { fel: 'oricand' }, 2: { fel: 'oricand' }, 3: { fel: 'oricand' }, 4: { fel: 'oricand' }, 5: { fel: 'oricand' }, 6: { fel: 'oricand' } };
  const C = porneste([
    { id: 'e3', name: 'Stan Radu', lastName: 'Stan', firstName: 'Radu', includedHours: 20, weeklyLimit: 7, payments: [],
      dispZile: zileLibere, dispDate: { [zi(1)]: { fel: 'nu' }, [zi(2)]: { fel: 'dupa', lo: 990 } } },
  ]);
  const p = unelte(C); await p.gata();
  p.clic([...p.doc().querySelectorAll('nav button')].find(x => /Plan/.test(x.textContent))); await pauza(800);
  p.clic([...p.doc().querySelectorAll('button')].find(x => /Generează plan/.test(x.textContent))); await pauza(1800);
  const t = p.doc().body.textContent.replace(/\s+/g, ' ');
  const randuri = [...t.matchAll(/(Lun|Mar|Mie|Joi|Vin|Sâm|Dum) (\d+) · (\d\d:\d\d)Stan Radu/g)].map(x => ({ zi: Number(x[2]), ora: x[3] }));
  const nr = (k) => Number(zi(k).slice(8));
  cer('planul i-a propus ședințe', randuri.length >= 3, randuri.map(x => x.zi + ' ' + x.ora).join(', '));
  cer('  niciuna în ziua în care a spus că nu poate', !randuri.some(x => x.zi === nr(1)), 'marți ' + nr(1));
  const miercuri = randuri.filter(x => x.zi === nr(2));
  cer('  în ziua „de la 16:30”, doar de la 16:30', miercuri.every(x => x.ora >= '16:30'), miercuri.map(x => x.ora).join(', ') || 'nicio ședință miercuri');

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(56) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
