/* Opțiunile la îndemână: „+" de pe Acasă strânge acțiunile într-o fereastră,
   Calendarul își ține cele două opțiuni pe un rând, iar pe fișa elevului
   plata stă sus, lângă creion și „Ședință nouă".                            */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const azi = (() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();
const rez = []; const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students: [{ id: 'e1', name: 'Popescu Andrei', lastName: 'Popescu', firstName: 'Andrei', includedHours: 15, weeklyLimit: 3, payments: [] }],
      sessions: [], settings: { workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei' } }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
const tab = (re) => clic([...doc().querySelectorAll('nav button')].find(x => re.test(x.textContent)));
const buton = (re, unde) => [...(unde || doc()).querySelectorAll('button')].find(x => re.test(x.textContent.trim()));
const foaie = () => doc().querySelector('[data-ias-foaie-actiuni]');
const deschide = async () => { tab(/Acasă/); await pauza(500); clic(doc().querySelector('[data-ias-actiuni]')); await pauza(500); };
(async () => {
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);

  cer('pe Acasă e un „+" pentru acțiuni', !!doc().querySelector('[data-ias-actiuni]') && doc().querySelector('[data-ias-actiuni]').getAttribute('aria-label') === 'Acțiuni');
  await deschide();
  const nume = [...foaie().querySelectorAll('button')].map(b => b.textContent.trim());
  cer('  cu șase acțiuni, pe două grupe', nume.join(' | ') === 'Ședință nouă | Indisponibil | Planificator | Elev nou | Când sunt ocupat | Setări'
    && /Programare/.test(foaie().textContent) && /Elevi/.test(foaie().textContent), nume.join(' | '));

  clic(buton(/^Ședință nouă$/, foaie())); await pauza(700);
  cer('„Ședință nouă" deschide formularul de ședință', !foaie() && [...doc().querySelectorAll('.sheet-anim')].some(f => /Ședință nouă/i.test(f.textContent)));
  clic(doc().querySelector('.btn-inchide')); await pauza(700);
  [...doc().querySelectorAll('.ecran-peste button')].filter(b => /^Renunță|Închide fără/.test(b.textContent.trim())).forEach(clic); await pauza(400);

  await deschide(); clic(buton(/^Indisponibil$/, foaie())); await pauza(800);
  cer('„Indisponibil" duce în Calendar, cu formularul deschis', [...doc().querySelectorAll('input')].some(x => /revizie/.test(x.placeholder || '')));
  clic(buton(/^Renunță$/)); await pauza(300);

  await deschide(); clic(buton(/^Când sunt ocupat$/, foaie())); await pauza(800);
  cer('„Când sunt ocupat" deschide textul pentru elev', [...doc().querySelectorAll('.sheet-anim')].some(f => /C[âa]nd sunt ocupat/i.test(f.textContent)));
  clic(doc().querySelector('.btn-inchide')); await pauza(600);

  await deschide(); clic(buton(/^Elev nou$/, foaie())); await pauza(700);
  cer('„Elev nou" deschide fișa goală', [...doc().querySelectorAll('.sheet-anim')].some(f => /Adaugă elev/i.test(f.textContent)));
  clic(doc().querySelector('.btn-inchide')); await pauza(700);
  [...doc().querySelectorAll('.ecran-peste button')].filter(b => /^Renunță|Închide fără/.test(b.textContent.trim())).forEach(clic); await pauza(400);

  await deschide(); clic(buton(/^Planificator$/, foaie())); await pauza(600);
  cer('„Planificator" duce la Plan', /Generează plan/.test(doc().body.textContent));
  await deschide(); clic(buton(/^Setări$/, foaie())); await pauza(600);
  cer('„Setări" duce la Setări', !!doc().querySelector('[data-ias-grup-setari]'));

  /* Calendarul: cele două opțiuni, pe un rând */
  tab(/Calendar/); await pauza(700);
  const m = buton(/^Marchează indisponibil$/), o2 = buton(/^Când sunt ocupat$/);
  cer('în Calendar, cele două opțiuni stau pe același rând', !!m && !!o2 && m.parentElement === o2.parentElement && /flex/.test(m.parentElement.className));
  cer('  iar bara lată de deasupra săptămânii nu mai e', !buton(/text pentru elev$/));

  /* fișa elevului: plata, sus */
  tab(/Elevi/); await pauza(600);
  clic([...doc().querySelectorAll('button, div')].find(x => /^Popescu Andrei/.test(x.textContent.trim()) && x.tagName === 'BUTTON') || [...doc().querySelectorAll('*')].find(x => x.children.length === 0 && x.textContent.trim() === 'Popescu Andrei'));
  await pauza(1300);
  const plata = doc().querySelector('[data-ias-plata-sus]');
  const rand = plata ? [...plata.parentElement.children].map(b => b.getAttribute('aria-label') || b.textContent.trim()) : [];
  cer('pe fișă: creion, plată, „Ședință nouă" — pe un rând', rand.join(' | ') === 'Editează | Trece o plată | Ședință nouă', rand.join(' | '));
  clic(plata); await pauza(600);
  cer('  plata de sus deschide aceeași fereastră de plată', [...doc().querySelectorAll('.sheet-anim')].some(f => /Achit|Plat/i.test(f.textContent) && f.querySelector('input')));

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(58) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
