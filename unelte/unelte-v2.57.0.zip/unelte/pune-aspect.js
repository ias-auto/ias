/* Pune stilul din aspect2027.css în aplicație, între două semne.
   Stilul aplicației trăiește într-un șir din parti/aplicatie.js; aici îl
   lipim la coada lui, ca regulile noi să vină după cele vechi. Rulat a doua
   oară, înlocuiește ce a pus prima dată.
   Rulare:  node pune-aspect.js                                             */
const fs = require('fs');
const F = 'parti/aplicatie.js';
const A = '/* >>> IAS-2027 */', Z = '/* <<< IAS-2027 */';
let cod = fs.readFileSync(F, 'utf8');
const css = fs.readFileSync(fs.existsSync('aspect2027.css') ? 'aspect2027.css' : 'unelte/aspect2027.css', 'utf8')
  .replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$\{/g, '\\${').replace(/\s+$/, '');
const bloc = A + '\n' + css + '\n        ' + Z;

if (cod.includes(A)) {
  const i = cod.indexOf(A), j = cod.indexOf(Z);
  if (j < i) { console.error('✕ Semnele sunt încurcate. Nu ating nimic.'); process.exit(1); }
  cod = cod.slice(0, i) + bloc + cod.slice(j + Z.length);
} else {
  /* Coada stilului: ultima regulă veche, apoi sfârșitul șirului. */
  const ancora = '.bg-amber-500 { background-color: #2a1800 !important; }\n      `)';
  if (cod.split(ancora).length !== 2) { console.error('✕ Nu găsesc coada stilului. Nu ating nimic.'); process.exit(1); }
  cod = cod.replace(ancora, '.bg-amber-500 { background-color: #2a1800 !important; }\n\n        ' + bloc + '\n      `)');
}
fs.writeFileSync(F, cod);
console.log('  stilul 2027 e în aplicație:', css.split('\n').length, 'rânduri');
