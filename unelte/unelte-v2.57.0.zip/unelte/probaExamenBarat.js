/* Intervalul marcat indisponibil peste un examen le poartă pe amândouă: ziua
   rămâne însemnată în bandă, iar rândurile din grilă arată și examenul, și
   bararea.                                                                   */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const azi = new Date().toISOString().slice(0, 10);

const rez = [];
const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);

const students = [
  /* examen practic azi, dimineața: 08:30–12:30 */
  { id: 'e1', name: 'Examen Ana', lastName: 'Examen', firstName: 'Ana',
    includedHours: 15, weeklyLimit: 3, payments: [], examDate: azi, examPeriod: 'am' },
  /* teoretic azi, la 16:00 */
  { id: 't1', name: 'Teorie Barbu', lastName: 'Teorie', firstName: 'Barbu',
    includedHours: 15, weeklyLimit: 3, payments: [], theoryExamDate: azi, theoryExamOra: 960 },
];
const settings = {
  workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 510, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei',
  blocks: [
    { id: 'b1', date: azi, allDay: false, startMin: 510, endMin: 600, note: 'drum la poligon' },  // peste examen
    { id: 'b2', date: azi, allDay: false, startMin: 840, endMin: 900 },                             // pe gol
    { id: 'b3', date: azi, allDay: false, startMin: 960, endMin: 1020 },                            // peste teoretic
  ],
};

const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    w.localStorage.setItem('ias:app-data', JSON.stringify({ students, sessions: [], settings }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({
      cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'],
    }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {};
    w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const stil = (el) => (el && el.getAttribute('style')) || '';
const curat = (el) => el.textContent.replace(/\s+/g, ' ').trim();

(async () => {
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f =>
    clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);
  clic([...doc().querySelectorAll('nav button')].find(x => /Calendar/.test(x.textContent)));
  await pauza(900);

  /* ---- banda săptămânii ---- */
  const nr = String(Number(azi.slice(8)));
  const zi = [...doc().querySelectorAll('button')]
    .filter(x => /flex-col items-center py-2 rounded-xl border/.test(x.className || ''))
    .find(x => (x.textContent.match(/\d+/) || [''])[0] === nr);
  cer('ziua rămâne însemnată ca zi de examen', !!zi && /var\(--violet\)/.test(stil(zi)),
    'chenar mov în bandă');
  cer('  și poartă și semnul de indisponibil', !!zi && /!/.test(zi.textContent),
    'amândouă deodată, nu una în locul celeilalte');

  /* ---- grila zilei ---- */
  const amestecate = [...doc().querySelectorAll('[data-ias-rand="examen-indisponibil"]')];
  const simple = [...doc().querySelectorAll('[data-ias-rand="indisponibil"]')];
  const peExamen = amestecate.filter(x => /^0[89]:\d\d\s*Examen · indisponibil/.test(curat(x)));
  cer('intervalul barat peste examen le arată pe amândouă', peExamen.length >= 2,
    peExamen.map(curat).slice(0, 3).join(' | ') || 'niciun rând');
  cer('  cu chenarul examenului și hașura încrucișată',
    peExamen.length > 0 && peExamen.every(x => /border-color: var\(--violet\)/.test(stil(x))
      && (stil(x).match(/repeating-linear-gradient/g) || []).length === 2),
    'mov + hașura de „indisponibil"');
  cer('  și păstrează motivul scris de tine',
    peExamen.some(x => /drum la poligon/.test(x.textContent)));

  const examenCurat = [...doc().querySelectorAll('button')]
    .filter(x => /^1[01]:\d\d\s*Examen$/.test(curat(x)));
  cer('restul dimineții rămâne „Examen", ca înainte', examenCurat.length >= 2,
    examenCurat.map(curat).slice(0, 3).join(' | '));

  cer('bararea pe un gol rămâne simplă', simple.some(x => /^14:\d\d\s*Indisponibil$/.test(curat(x)))
    && simple.every(x => !/var\(--violet\)/.test(stil(x))),
    simple.map(curat).slice(0, 2).join(' | '));

  const peTeoretic = amestecate.find(x => /^16:00\s*Teoretic · Teorie · indisponibil/.test(curat(x)));
  cer('la fel și peste teoretic', !!peTeoretic, peTeoretic ? curat(peTeoretic) : 'nu-l găsesc');

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(48) + (dt || '')));
  const cazute = rez.filter(r => r[0] === '✕').length;
  console.log('\n  ' + (rez.length - cazute) + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
