/* Ceasul aplicației, oprit la o clipă aleasă. Probele care citesc planul nu
   trebuie să depindă de ziua și ora la care le rulezi: sâmbătă după-amiază,
   „prima sâmbătă" din plan e chiar azi, pe jumătate trecută, și orele ies
   altele decât luni dimineața — fără ca aplicația să fi greșit ceva.          */
module.exports = function ceasFix(w, clipa) {
  const Adevarata = w.Date;
  const t0 = clipa.getTime();
  function Fixa(...a) { return a.length ? new Adevarata(...a) : new Adevarata(t0); }
  Fixa.prototype = Adevarata.prototype;
  Fixa.now = () => t0;
  Fixa.parse = Adevarata.parse;
  Fixa.UTC = Adevarata.UTC;
  w.Date = Fixa;
};
/* Lunea care urmează, la șapte dimineața: o săptămână întreagă în față. */
module.exports.luneaViitoare = () => {
  const d = new Date();
  d.setDate(d.getDate() + (((8 - d.getDay()) % 7) || 7));
  d.setHours(7, 0, 0, 0);
  return d;
};
