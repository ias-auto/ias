/* Cu o zi înainte de examenul practic, Acasă îți amintește să-ți faci o oră
   pentru spălat mașina. Anunțul duce la Calendar, cu formularul de interval
   indisponibil gata completat pe o oră liberă, și dispare după ce salvezi.   */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const ceasFix = require('./ceasFix.js');
const ACUM = ceasFix.luneaViitoare();                    // luni, 07:00
const iso = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const zi = (k) => { const d = new Date(ACUM); d.setDate(d.getDate() + k); return iso(d); };
const azi = zi(0), maine = zi(1);

const rez = [];
const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const elev = (id, nume, extra) => Object.assign({ id, name: nume, lastName: nume.split(' ')[0], firstName: nume.split(' ')[1], includedHours: 15, weeklyLimit: 3, payments: [] }, extra || {});

const porneste = (students, sessions, blocks) => new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    ceasFix(w, ACUM);
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students, sessions: sessions || [],
      settings: { workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei', blocks: blocks || [] },
    }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const unelte = (d) => {
  const doc = () => d.window.document;
  const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
  return {
    doc, clic,
    gata: async () => {
      await pauza(3200);
      [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
      await pauza(500);
    },
    anunt: () => doc().querySelector('[data-ias-spalat]'),
    tab: (re) => clic([...doc().querySelectorAll('nav button')].find(x => re.test(x.textContent))),
    date: () => JSON.parse(d.window.localStorage.getItem('ias:app-data')),
  };
};

(async () => {
  /* ---- 1. examen mâine: anunțul apare și duce la formular ---- */
  const d1 = porneste(
    [elev('e1', 'Popescu Andrei', { examDate: maine, examPeriod: 'am' }), elev('e2', 'Ionescu Maria')],
    [{ id: 's1', studentId: 'e2', date: azi, startMin: 480, endMin: 570, status: 'scheduled', location: 'Liceu' }]);
  const u1 = unelte(d1); await u1.gata();
  const a1 = u1.anunt();
  cer('cu o zi înainte de examen, Acasă îți amintește', !!a1, a1 ? a1.textContent.replace(/\s+/g, ' ').trim() : 'niciun anunț');
  cer('  spune al cui e examenul și ce ai de făcut', !!a1 && /Popescu Andrei/.test(a1.textContent) && /speli mașina/.test(a1.textContent));

  u1.clic(a1); await pauza(900);
  const motiv = [...u1.doc().querySelectorAll('input')].find(x => /revizie/.test(x.placeholder || ''));
  cer('atingerea deschide Calendarul cu formularul gata', !!motiv && motiv.value === 'Spălat mașina',
    motiv ? `motiv: „${motiv.value}"` : 'formularul nu s-a deschis');
  const sel = [...u1.doc().querySelectorAll('select')].filter(x => x.closest('.rounded-xl.bg-slate-50'));
  const [de, pana] = sel.map(x => Number(x.value));
  cer('  pe o oră întreagă', sel.length === 2 && pana - de === 60, `${de}–${pana} min`);
  cer('  prima liberă: după ședința de la 08:00', de === 570, `începe la ${Math.floor(de / 60)}:${String(de % 60).padStart(2, '0')}`);

  u1.clic([...u1.doc().querySelectorAll('button')].find(x => x.textContent.trim() === 'Salvează')); await pauza(700);
  const b = (u1.date().settings.blocks || [])[0];
  cer('salvat, intervalul e în ziua de azi', !!b && b.date === azi && b.startMin === 570 && b.endMin === 630 && b.note === 'Spălat mașina',
    b ? `${b.date} ${b.startMin}–${b.endMin} „${b.note}"` : 'nimic salvat');
  u1.tab(/Acasă/); await pauza(700);
  cer('iar anunțul dispare', !u1.anunt());
  u1.tab(/Calendar/); await pauza(700);
  cer('a doua oară, Calendarul nu mai deschide formularul singur',
    ![...u1.doc().querySelectorAll('input')].some(x => /revizie/.test(x.placeholder || '')));

  /* ---- 2. când nu e cazul ---- */
  const d2 = porneste([
    elev('e1', 'Popescu Andrei', { examDate: zi(2), examPeriod: 'am' }),           // poimâine
    elev('e2', 'Ionescu Maria', { theoryExamDate: maine, theoryExamOra: 600 }),      // teoretic mâine: nu cere mașina
    elev('e3', 'Stan Radu', { examDate: maine, examResult: 'promovat' }),            // a promovat deja
    elev('e4', 'Marin Elena', { examDate: maine, withdrawn: true }),                 // retrasă
  ]);
  const u2 = unelte(d2); await u2.gata();
  cer('fără examen practic mâine, niciun anunț', !u2.anunt(),
    'poimâine, teoretic, promovat, retras — niciunul nu-l aprinde');

  /* ---- 3. mai mulți elevi în aceeași zi: un singur anunț ---- */
  const d3 = porneste([
    elev('e1', 'Popescu Andrei', { examDate: maine, examPeriod: 'am' }),
    elev('e2', 'Ionescu Maria', { examDate: maine, examPeriod: 'am' }),
  ], [], [{ id: 'b0', date: azi, allDay: false, startMin: 600, endMin: 660, note: 'drum la service' }]);
  const u3 = unelte(d3); await u3.gata();
  const toate = u3.doc().querySelectorAll('[data-ias-spalat]');
  cer('doi elevi la examen mâine: un singur anunț', toate.length === 1 && /2 elevi/.test(toate[0].textContent),
    toate[0] ? toate[0].textContent.replace(/\s+/g, ' ').trim() : '');
  cer('  un interval pus pentru altceva nu-l stinge', toate.length === 1, '„drum la service" nu e spălat');

  /* ---- 4. și în Calendar, pe ziua dinaintea examenului ---- */
  const d4 = porneste([elev('e1', 'Popescu Andrei', { examDate: zi(3), examPeriod: 'am' })],
    [{ id: 's1', studentId: 'e1', date: zi(2), startMin: 480, endMin: 570, status: 'scheduled', location: 'Liceu' }]);
  const u4 = unelte(d4); await u4.gata();
  cer('cu trei zile înainte, Acasă nu spune nimic încă', !u4.anunt());
  u4.tab(/Calendar/); await pauza(700);
  const inZi = () => u4.doc().querySelector('[data-ias-spalat-zi]');
  cer('în Calendar, azi nu apare', !inZi());
  const nr = String(Number(zi(2).slice(8)));
  const ziua = [...u4.doc().querySelectorAll('button')]
    .filter(x => /flex-col items-center py-2 rounded-xl border/.test(x.className || ''))
    .find(x => (x.textContent.match(/\d+/) || [''])[0] === nr);
  u4.clic(ziua); await pauza(600);
  cer('dar apare pe ziua dinaintea examenului', !!inZi() && /A doua zi e examenul lui Popescu Andrei/.test(inZi().textContent),
    inZi() ? inZi().textContent.replace(/\s+/g, ' ').trim() : 'niciun anunț pe ziua aceea');
  u4.clic(inZi()); await pauza(500);
  const m4 = [...u4.doc().querySelectorAll('input')].find(x => /revizie/.test(x.placeholder || ''));
  const s4 = [...u4.doc().querySelectorAll('select')].filter(x => x.closest('.rounded-xl.bg-slate-50')).map(x => Number(x.value));
  cer('  atins, deschide formularul pe o oră liberă a zilei aceleia', !!m4 && m4.value === 'Spălat mașina' && s4[0] === 570 && s4[1] === 630,
    s4.join('–') + ' min, după ședința de la 08:00');
  u4.clic([...u4.doc().querySelectorAll('button')].find(x => x.textContent.trim() === 'Salvează')); await pauza(600);
  const b4 = (u4.date().settings.blocks || [])[0];
  cer('  salvat pe ziua aceea, iar anunțul dispare', !!b4 && b4.date === zi(2) && !inZi(), b4 ? b4.date : '');

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(54) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
