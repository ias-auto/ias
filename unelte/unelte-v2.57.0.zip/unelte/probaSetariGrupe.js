/* Setările sunt strânse în cinci grupe, dar nu lipsește niciun rând: fiecare
   deschide aceeași fereastră ca înainte. Căutarea le găsește după cuvinte,
   iar tema se schimbă dintr-o atingere.                                      */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const azi = (() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();
const rez = []; const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    w.localStorage.setItem('ias:app-data', JSON.stringify({ students: [], sessions: [], settings: { workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei' } }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
const scrie = (el, v) => { const set = Object.getOwnPropertyDescriptor(d.window.HTMLInputElement.prototype, 'value').set; set.call(el, v); el.dispatchEvent(new d.window.Event('input', { bubbles: true })); };
const TOATE = ['Vehiculul din antet', 'Temă', 'Program de lucru', 'Elevi noi și monedă', 'Numele tău și școala', 'Programul trimis de elevi',
  'Locații de start', 'Mașinile mele', 'Amintiri pe telefon', 'Backup și date', 'Licențe', 'Acces', 'Ajutor și feedback', 'Despre aplicație'];
(async () => {
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);
  clic(doc().querySelector('[data-ias-setari]')); await pauza(700);

  const grupe = () => [...doc().querySelectorAll('[data-ias-grup-setari]')];
  const randuri = (g) => [...g.children[1].querySelectorAll('button')];
  const numeRand = (b) => b.querySelector('span').textContent.trim();
  const deschisa = (g) => g.children[1].style.display !== 'none';
  cer('cinci grupe', grupe().length === 5, grupe().map(g => g.querySelector('button .font-semibold').textContent).join(' · '));
  const inGrupe = grupe().flatMap(g => randuri(g).map(numeRand));
  cer('toate cele 14 rânduri sunt la locul lor, fiecare o singură dată',
    TOATE.every(n => inGrupe.filter(x => x === n).length === 1) && inGrupe.length === TOATE.length,
    inGrupe.length + ' rânduri; lipsă: ' + (TOATE.filter(n => !inGrupe.includes(n)).join(', ') || 'niciunul'));
  cer('o singură grupă e desfăcută la început', grupe().filter(deschisa).length === 1 && deschisa(grupe()[0]));
  cer('  cu antetul care spune pe scurt ce e înăuntru', /08:00.20:00/.test(grupe()[0].querySelector('button').textContent));

  clic(grupe()[4].querySelector('button')); await pauza(300);
  cer('atingi altă grupă: se desface ea și se strânge cealaltă', deschisa(grupe()[4]) && !deschisa(grupe()[0]));
  clic(randuri(grupe()[4]).find(b => numeRand(b) === 'Backup și date')); await pauza(600);
  const foaie = doc().querySelector('.sheet-anim');
  cer('rândul deschide aceeași fereastră ca înainte', !!foaie && /Backup și date/i.test(foaie.textContent) && /Descarc/.test(foaie.textContent));
  clic(doc().querySelector('.btn-inchide')); await pauza(600);

  /* căutarea */
  const camp = doc().querySelector('[data-ias-cauta-setari]');
  scrie(camp, 'pauză'); await pauza(300);
  const gasite = () => [...(doc().querySelector('[data-ias-rezultate-setari]') || { querySelectorAll: () => [] }).querySelectorAll('button')].map(numeRand);
  cer('„pauză" găsește programul de lucru', gasite().join() === 'Program de lucru', gasite().join(', '));
  cer('  iar grupele se dau la o parte cât cauți', grupe().every(g => g.style.display === 'none'));
  scrie(camp, 'JUDET'); await pauza(300);
  cer('fără diacritice și cu litere mari merge la fel', gasite().join() === 'Elevi noi și monedă', gasite().join(', '));
  scrie(camp, 'xyzq'); await pauza(300);
  cer('când nu găsește nimic, o spune', /Nu am găsit nimic/.test(doc().querySelector('[data-ias-rezultate-setari]').textContent));
  scrie(camp, ''); await pauza(300);
  cer('ștearsă căutarea, grupele revin cum erau', grupe().every(g => g.style.display !== 'none') && deschisa(grupe()[4]));

  /* tema, dintr-o atingere */
  const tema = [...doc().querySelector('[data-ias-tema-rapida]').querySelectorAll('button')];
  cer('tema stă sus: Sistem, Zi, Noapte', tema.map(b => b.textContent.trim()).join(' ') === 'Sistem Zi Noapte' && tema[0].getAttribute('aria-pressed') === 'true');
  clic(tema[2]); await pauza(400);
  const dupa = JSON.parse(d.window.localStorage.getItem('ias:app-data')).settings.theme;
  cer('  atinsă, se schimbă pe loc', dupa === 'dark' && doc().querySelector('[data-skin]').getAttribute('data-skin') === 'dark', 'theme: ' + dupa);
  clic([...doc().querySelector('[data-ias-tema-rapida]').querySelectorAll('button')][0]); await pauza(300);
  cer('  iar „Sistem" o lasă din nou după telefon', JSON.parse(d.window.localStorage.getItem('ias:app-data')).settings.theme === 'system');

  /* grupa rămasă deschisă se ține minte */
  clic([...doc().querySelectorAll('nav button')][0]); await pauza(500);
  clic(doc().querySelector('[data-ias-setari]')); await pauza(600);
  cer('la întoarcere, găsești desfăcută grupa în care ai fost', deschisa(grupe()[4]) && !deschisa(grupe()[0]));

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(60) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
