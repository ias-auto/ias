/* Înfățișarea 2027 e doar înfățișare: stilul e pus, bara are cinci file,
   Setările se deschid de la rotiță, GSAP vine prin CDN, iar fără el aplicația
   merge la fel. Vibrația se dă doar la acțiunile care schimbă ceva.          */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const azi = (() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();

const rez = [];
const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const vibratii = [];

const d = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    w.localStorage.setItem('ias:app-data', JSON.stringify({
      students: [{ id: 'e1', name: 'Popescu Andrei', lastName: 'Popescu', firstName: 'Andrei', includedHours: 15, weeklyLimit: 3, payments: [] }],
      sessions: [], settings: { workDays: [0, 1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei' },
    }));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
    w.navigator.vibrate = (ms) => { vibratii.push(ms); return true; };
  },
});
const doc = () => d.window.document;
const clic = (el) => el && el.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
const buton = (re) => [...doc().querySelectorAll('button')].find(x => re.test(x.textContent.trim()));

(async () => {
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);

  /* ---- stilul ---- */
  const stil = [...doc().querySelectorAll('style')].map(s => s.textContent).join('\n');
  cer('stilul nou e în aplicație, după cel vechi',
    stil.includes('IAS-2027') && stil.indexOf('IAS-2027') > stil.indexOf('SISTEM DE CULORI'));
  cer('  fundal adânc, cu pete de lumină care se mișcă încet',
    /\[data-skin="dark"\]\{[^}]*--bg:#04070d/.test(stil) && /iasPete 80s/.test(stil));
  cer('  sticlă: estompare în spate și muchie luminoasă',
    (stil.match(/backdrop-filter:blur/g) || []).length >= 4 && /--ias-muchie/.test(stil));
  cer('  atingerea strânge butonul la 0.95, elastic, fără evidențierea albastră',
    /scale:\.95/.test(stil) && /cubic-bezier\(\.34,1\.56,\.64,1\)/.test(stil) && /-webkit-tap-highlight-color:transparent/.test(stil));
  cer('  pe întuneric, varianta aleasă e chihlimbar, ca fila activă',
    /\[data-skin="dark"\] \.bg-slate-900\.border-slate-900,\s*\[data-skin="dark"\] \[data-ias-ales\]\{\s*background-color:var\(--accent-soft\)/.test(stil));
  cer('  cine a cerut mai puțină mișcare e ascultat', /prefers-reduced-motion: reduce\)\{\s*\[data-skin\]\.min-h-screen::before/.test(stil));
  cer('  la tipărit rămâne alb', /@media print\{\s*\[data-skin\]\.min-h-screen\{ background:#fff/.test(stil));

  /* ---- antetul cu mașina ---- */
  const antet = doc().querySelector('[data-ias-antet]');
  cer('antetul cu mașina e la locul lui', !!antet && /BUN VENIT/i.test(antet.textContent),
    antet ? 'borderRadius ' + antet.style.borderRadius : 'lipsește');

  cer('  înăuntrul lui, culorile sunt cele vechi și nimic nou nu ajunge la el',
    /\[data-skin="dark"\] \[data-ias-antet\]\{[^}]*--accent:#e0a13a/.test(stil) && /\[data-ias-antet\] \.rounded-2xl\{ border-radius:20px/.test(stil)
    && !/\[data-ias-antet\]\{ box-shadow/.test(stil));
  cer('  estomparea cardurilor se oprește când cardul ține o fereastră', /\.bg-white\.border[^{,]*:not\(:has\(\.ecran-peste\)\)/.test(stil) && /\.bg-white\.border:not\(input\)/.test(stil));

  /* ---- bara și rotița ---- */
  const file = [...doc().querySelectorAll('nav button')].map(x => x.textContent.trim());
  cer('bara de jos are cinci file', file.join(' ') === 'Acasă Calendar Elevi Plan Finanțe', file.join(' · '));
  const rotita = doc().querySelector('[data-ias-setari]');
  cer('rotița stă pe Acasă, cu nume pentru cititorul de ecran', !!rotita && rotita.getAttribute('aria-label') === 'Setări' && !rotita.closest('[data-ias-antet]'));
  clic(rotita); await pauza(700);
  cer('  și deschide Setările', !!buton(/^Program de lucru/) && !!buton(/^Backup și date/));
  clic([...doc().querySelectorAll('nav button')][0]); await pauza(500);
  cer('  din Setări te întorci cu bara de jos', !!doc().querySelector('[data-ias-antet]'));

  /* ---- GSAP prin CDN, fără să depindă aplicația de el ---- */
  const g = doc().getElementById('ias-gsap');
  cer('GSAP e cerut de pe CDN, cu amprentă de siguranță',
    !!g && /^https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/gsap\/3\.12\.5\/gsap\.min\.js$/.test(g.src) && /^sha512-/.test(g.integrity) && g.crossOrigin === 'anonymous',
    g ? g.src.replace('https://', '') : 'fără etichetă');
  cer('  fără el, nimic nu rămâne ascuns', typeof d.window.gsap === 'undefined'
    && ![...doc().querySelectorAll('[data-skin] *')].some(x => x.style.opacity === '0'),
    'aici GSAP n-a ajuns, iar ecranul e întreg');
  const sw = fs.existsSync('sw.js') ? fs.readFileSync('sw.js', 'utf8') : '';
  cer('  și se ține minte pentru mersul fără semnal', /cdnjs\.cloudflare\.com\/ajax\/libs\/gsap\//.test(sw));

  /* ---- vibrația ---- */
  vibratii.length = 0;
  clic([...doc().querySelectorAll('nav button')][1]); await pauza(600);        // Calendar: doar mers
  cer('mersul dintr-o filă în alta nu vibrează', vibratii.length === 0, vibratii.length + ' vibrații');
  clic(buton(/^Marchează indisponibil$/)); await pauza(400);
  vibratii.length = 0;
  clic(buton(/^Renunță$/)); await pauza(300);
  cer('„Renunță" nu vibrează', vibratii.length === 0);
  clic(buton(/^Marchează indisponibil$/)); await pauza(400);
  vibratii.length = 0;
  clic(buton(/^Salvează$/)); await pauza(400);
  cer('„Salvează" dă o vibrație scurtă', vibratii.length === 1 && vibratii[0] === 15, vibratii.join(', ') + ' ms');
  delete d.window.navigator.vibrate;
  let cazut = false;
  try { clic(buton(/^Marchează indisponibil$/)); await pauza(300); clic(buton(/^Salvează$/)); await pauza(300); } catch (e) { cazut = true; }
  cer('pe telefonul care nu vibrează (iPhone) nu se strică nimic', !cazut && (JSON.parse(d.window.localStorage.getItem('ias:app-data')).settings.blocks || []).length === 2);

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(58) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
