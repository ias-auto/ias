/* Ziua pe o axă, în Calendar. Lista rămâne cum era și e cea de la început;
   axa arată aceleași lucruri, fiecare cât e de lung: ședințele cu semnul
   stării, golurile de atins, examenul, teoreticul, intervalele barate.       */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const ceasFix = require('./ceasFix.js');
const ACUM = ceasFix.luneaViitoare();                    // luni, 07:00
const iso = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const azi = iso(ACUM);
const rez = []; const cer = (n, ok, d) => rez.push([ok ? '✓' : '✕', n, d || '']);
const pauza = (ms) => new Promise(r => setTimeout(r, ms));
const el = (id, ln, fn, x) => Object.assign({ id, name: ln + ' ' + fn, lastName: ln, firstName: fn, includedHours: 15, weeklyLimit: 3, payments: [] }, x || {});
const date = {
  students: [el('e1', 'Popescu', 'Andrei'), el('e2', 'Ionescu', 'Maria', { theoryExamDate: azi, theoryExamOra: 1020 }), el('e3', 'Dumitru', 'Vlad'),
    el('e4', 'Stan', 'Radu'), el('e5', 'Marin', 'Elena', { examDate: azi, examPeriod: 'am' }), el('e6', 'Vasile', 'Dan')],
  sessions: [
    { id: 's1', studentId: 'e1', date: azi, startMin: 480, endMin: 570, status: 'completed', location: 'Piața Gării' },
    { id: 's2', studentId: 'e3', date: azi, startMin: 600, endMin: 690, status: 'scheduled', location: 'Liceu' },
    { id: 's3', studentId: 'e4', date: azi, startMin: 870, endMin: 960, status: 'pending', location: 'Piața Gării' },
    { id: 's4', studentId: 'e6', date: azi, startMin: 900, endMin: 990, status: 'scheduled', location: 'Liceu' },
  ],
  settings: { workDays: [1, 2, 3, 4, 5, 6], startMin: 480, endMin: 1200, sessionMin: 90, stepMin: 30, currency: 'lei',
    blocks: [{ id: 'b1', date: azi, allDay: false, startMin: 750, endMin: 810, note: 'masa' }] },
};
const porneste = (vedere) => new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x/',
  beforeParse(w) {
    ceasFix(w, ACUM);
    w.localStorage.setItem('ias:app-data', JSON.stringify(date));
    w.localStorage.setItem('ias:licenta', JSON.stringify({ cod: 'IAS9F3K7QX2', stare: 'ok', rol: 'proprietar', pana: '2099-12-31', verificatLa: azi, drepturi: ['*'] }));
    w.localStorage.setItem('ias:backup', azi);
    if (vedere) w.localStorage.setItem('ias:vedere-zi', vedere);
    w.ResizeObserver = function () { this.observe = () => {}; this.disconnect = () => {}; };
    w.scrollBy = () => {}; w.HTMLElement.prototype.scrollIntoView = function () {};
  },
});

(async () => {
  const d = porneste();
  const doc = () => d.window.document;
  const clic = (x) => x && x.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));
  const inchide = async () => { clic(doc().querySelector('.btn-inchide')); await pauza(600);
    [...doc().querySelectorAll('.ecran-peste button')].filter(b => /^Renunță|Închide fără/.test(b.textContent.trim())).forEach(clic); await pauza(400); };
  await pauza(3200);
  [...doc().querySelectorAll('.ecran-peste')].forEach(f => clic([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(500);
  clic([...doc().querySelectorAll('nav button')].find(x => /Calendar/.test(x.textContent))); await pauza(900);

  const comutator = doc().querySelector('[data-ias-vedere]');
  cer('deasupra zilei: „Listă” și „Axă”', !!comutator && [...comutator.querySelectorAll('button')].map(b => b.textContent).join(' ') === 'Listă Axă');
  cer('  la început, lista de până acum', comutator.getAttribute('data-ias-vedere') === 'lista' && !doc().querySelector('[data-ias-axa]')
    && [...doc().querySelectorAll('button')].some(b => /^\d\d:\d\dLiber/.test(b.textContent.trim())));

  clic(doc().querySelector('[data-ias-vedere-buton="axa"]')); await pauza(500);
  const axa = doc().querySelector('[data-ias-axa]');
  cer('„Axă” arată ziua pe o axă', !!axa && doc().querySelector('[data-ias-vedere]').getAttribute('data-ias-vedere') === 'axa');
  const ses = [...doc().querySelectorAll('[data-ias-sedinta-axa]')];
  cer('  toate ședințele zilei, în ordine', ses.map(b => b.getAttribute('data-ias-sedinta-axa')).join() === 's1,s2,s3,s4');
  const inalt = (id) => parseFloat(doc().querySelector(`[data-ias-sedinta-axa="${id}"]`).style.height);
  const sus = (id) => parseFloat(doc().querySelector(`[data-ias-sedinta-axa="${id}"]`).style.top);
  cer('  fiecare cât e de lungă: 1:30 = o oră și jumătate', inalt('s1') === 81 && sus('s2') - sus('s1') === 112, 'o oră = 56 de puncte');
  /* Browserul socotește formula: jumătate de lățime fiecare, a doua de la jumătate. */
  const stil = (id) => doc().querySelector(`[data-ias-sedinta-axa="${id}"]`).getAttribute('style');
  cer('  cele suprapuse stau una lângă alta', /width: calc\(50% - /.test(stil('s3')) && /width: calc\(50% - /.test(stil('s4'))
    && /left: calc\(0% \+ 44px\)/.test(stil('s3')) && /left: calc\(50% \+ 22px\)/.test(stil('s4')), 'Stan Radu și Vasile Dan, 14:30 și 15:00');
  cer('  cele singure ocupă tot rândul', /width: calc\(100% - 44px\)/.test(stil('s1')), stil('s1').match(/width: [^;]+/)[0]);
  cer('  fiecare cu semnul stării', ses.every(b => b.querySelector('svg')) && /Efectuată/.test(ses[0].textContent) && /Programată/.test(ses[1].textContent));

  const goluri = [...doc().querySelectorAll('[data-ias-gol]')].map(b => b.getAttribute('aria-label'));
  cer('golurile, cât sunt de mari', goluri.join(' | ') === 'Liber 09:30–10:00: adaugă o ședință | Liber 11:30–12:30: adaugă o ședință | Liber 13:30–14:30: adaugă o ședință | Liber 16:30–20:00: adaugă o ședință', goluri.join(' | '));
  const exam = doc().querySelector('[data-ias-axa-examen]');
  cer('examenul practic: banda dimineții, cu numele', !!exam && /Examen 08:30–12:30: Marin Elena/.test(exam.getAttribute('aria-label')));
  const golEx = doc().querySelector('[data-ias-gol="690"]').parentElement.textContent;
  cer('  golul din banda examenului scrie „Examen”', /Examen · Marin Elena/.test(golEx), golEx.replace(/\s+/g, ' '));
  const teo = doc().querySelector('[data-ias-axa-teoretic]');
  cer('teoreticul: linia la ora lui', !!teo && teo.getAttribute('aria-label') === 'Teoretic: Ionescu Maria, la 17:00');
  cer('  și pomenit în golul în care cade', /Teoretic Ionescu 17:00/.test(doc().querySelector('[data-ias-gol="990"]').parentElement.textContent));
  const bar = axa.querySelector('[data-ias-rand]');
  cer('intervalul barat, hașurat, cu motivul', !!bar && /12:30–13:30/.test(bar.textContent) && /masa/.test(bar.textContent) && /repeating-linear-gradient/.test(bar.getAttribute('style')));

  /* atingerile */
  clic(doc().querySelector('[data-ias-sedinta-axa="s2"]')); await pauza(700);
  cer('ședința atinsă se deschide, ca în listă', [...doc().querySelectorAll('.sheet-anim')].some(f => /Dumitru Vlad/.test(f.textContent)));
  await inchide();
  clic(doc().querySelector('[data-ias-gol="810"]')); await pauza(700);
  const foaie = [...doc().querySelectorAll('.sheet-anim')].pop();
  cer('golul atins deschide ședința nouă, la ora lui', !!foaie && /Ședință nouă/i.test(foaie.textContent) && /13:30/.test(foaie.textContent));
  await inchide();
  const cip = [...doc().querySelector('[data-ias-gol="990"]').parentElement.querySelectorAll('button')].find(b => /^\+ /.test(b.textContent));
  cer('„Umple golul” e și pe axă', !!cip, cip ? cip.textContent : 'nicio sugestie');
  clic(cip); await pauza(700);
  cer('  atinsă, deschide ședința cu elevul ales', [...doc().querySelectorAll('.sheet-anim')].some(f => cip && f.textContent.includes(cip.textContent.replace(/^\+ /, '').trim())));
  await inchide();

  cer('alegerea se ține minte pe telefon', d.window.localStorage.getItem('ias:vedere-zi') === 'axa');
  clic(doc().querySelector('[data-ias-vedere-buton="lista"]')); await pauza(400);
  cer('„Listă” aduce înapoi lista', !doc().querySelector('[data-ias-axa]') && d.window.localStorage.getItem('ias:vedere-zi') === 'lista');

  const d2 = porneste('axa');
  await pauza(3200);
  const doc2 = d2.window.document;
  const clic2 = (x) => x && x.dispatchEvent(new d2.window.MouseEvent('click', { bubbles: true }));
  [...doc2.querySelectorAll('.ecran-peste')].forEach(f => clic2([...f.querySelectorAll('button')].find(x => /Am înțeles|Închide/.test(x.textContent))));
  await pauza(400);
  clic2([...doc2.querySelectorAll('nav button')].find(x => /Calendar/.test(x.textContent))); await pauza(800);
  cer('redeschisă aplicația, pornește cu axa aleasă', !!doc2.querySelector('[data-ias-axa]'));

  console.log('');
  rez.forEach(([s, n, dt]) => console.log('  ' + s + ' ' + n.padEnd(54) + (dt || '')));
  console.log('\n  ' + rez.filter(r => r[0] === '✓').length + ' din ' + rez.length + ' verificări');
  process.exit(0);
})();
